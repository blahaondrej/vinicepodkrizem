<!-- product item-->
<div class="product-cat-mains">
    <div class="product-cat-img fl-wrap">
        <img src="<?php echo $url; ?>/images/vina/detail/ryzlink-rynsky-2015.jpg" alt="Rheinriesling 2015">
        <a href="<?php echo $urlde; ?>/vina/ryzlink-rynsky-2015">Detail</a>
    </div>
    <div class="product-cat-title">
        <h4><a href="<?php echo $urlde; ?>/vina/ryzlink-rynsky-2015">Rheinriesling 2015</a></h4>
        <div class="product-cats">Halbtrocken</div>
        <span class="product-price">&nbsp;</span>
    </div>
</div>
<!-- product item end-->