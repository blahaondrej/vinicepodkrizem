<!-- product item-->
<div class="product-cat-mains">
    <div class="product-cat-img fl-wrap">
        <img src="<?php echo $url; ?>/images/vina/detail/ryzlink-rynsky-2016.jpg" alt="Rheinriesling 2016">
        <a href="<?php echo $urlde; ?>/vina/ryzlink-rynsky-2016">Detail</a>
    </div>
    <div class="product-cat-title">
        <h4><a href="<?php echo $urlde; ?>/vina/ryzlink-rynsky-2016">Rheinriesling 2016</a></h4>
        <div class="product-cats">Halbtrocken</div>
        <span class="product-price">&nbsp;</span>
    </div>
</div>
<!-- product item end-->