<!-- product item-->
<div class="product-cat-mains">
    <div class="product-cat-img fl-wrap">
        <img src="<?php echo $url; ?>/images/vina/detail/hibernal-2017.jpg" alt="Hibernal 2017">
        <a href="<?php echo $urlde; ?>/vina/hibernal-2017">Detail</a>
    </div>
    <div class="product-cat-title">
        <h4><a href="<?php echo $urlde; ?>/vina/hibernal-2017">Hibernal 2017</a></h4>
        <div class="product-cats">Halbsüß</div>
        <span class="product-price">&nbsp;</span>
    </div>
</div>
<!-- product item end-->