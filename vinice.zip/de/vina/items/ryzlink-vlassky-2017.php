<!-- product item-->
<div class="product-cat-mains">
    <div class="product-cat-img fl-wrap">
        <img src="<?php echo $url; ?>/images/vina/detail/ryzlink-vlassky-2017.jpg" alt="Welschriesling 2017">
        <a href="<?php echo $urlde; ?>/vina/ryzlink-vlassky-2017">Detail</a>
    </div>
    <div class="product-cat-title">
        <h4><a href="<?php echo $urlde; ?>/vina/ryzlink-vlassky-2017">Welschriesling 2017</a></h4>
        <div class="product-cats">Halbtrocken</div>
        <span class="product-price">&nbsp;</span>
    </div>
</div>
<!-- product item end-->