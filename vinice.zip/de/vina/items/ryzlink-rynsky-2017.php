<!-- product item-->
<div class="product-cat-mains">
    <div class="product-cat-img fl-wrap">
        <img src="<?php echo $url; ?>/images/vina/detail/ryzlink-rynsky-2017.jpg" alt="Rheinriesling 2017">
        <a href="<?php echo $urlde; ?>/vina/ryzlink-rynsky-2017">Detail</a>
    </div>
    <div class="product-cat-title">
        <h4><a href="<?php echo $urlde; ?>/vina/ryzlink-rynsky-2017">Rheinriesling 2017</a></h4>
        <div class="product-cats">Halbsüß</div>
        <span class="product-price">&nbsp;</span>
    </div>
</div>
<!-- product item end-->