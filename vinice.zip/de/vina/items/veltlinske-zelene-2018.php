<!-- product item-->
<div class="product-cat-mains">
    <div class="product-cat-img fl-wrap">
        <img src="<?php echo $url; ?>/images/vina/detail/veltlinske-zelene-2018.jpg" alt="Grüner Veltliner 2018">
        <a href="<?php echo $urlde; ?>/vina/veltlinske-zelene-2018">Detail</a>
    </div>
    <div class="product-cat-title">
        <h4><a href="<?php echo $urlde; ?>/vina/veltlinske-zelene-2018">Grüner Veltliner 2018</a></h4>
        <div class="product-cats">Trocken</div>
        <span class="product-price">&nbsp;</span>
    </div>
</div>
<!-- product item end-->