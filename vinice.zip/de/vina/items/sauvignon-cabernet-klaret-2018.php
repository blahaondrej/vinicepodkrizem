<!-- product item-->
<div class="product-cat-mains">
    <div class="product-cat-img fl-wrap">
        <img src="<?php echo $url; ?>/images/vina/detail/sauvignon-cabernet-klaret-2018.jpg" alt="Sauvignon Cabernet Claret 2018">
        <a href="<?php echo $urlde; ?>/vina/sauvignon-cabernet-klaret-2018">Detail</a>
    </div>
    <div class="product-cat-title">
        <h4><a href="<?php echo $urlde; ?>/vina/sauvignon-cabernet-klaret-2018">Sauvignon Cabernet Claret 2018</a></h4>
        <div class="product-cats">Halbsüß</div>
        <span class="product-price">&nbsp;</span>
    </div>
</div>
<!-- product item end-->