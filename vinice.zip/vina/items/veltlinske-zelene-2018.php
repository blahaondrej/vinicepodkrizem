<!-- product item-->
<div class="product-cat-mains">
    <div class="product-cat-img fl-wrap">
        <img src="<?php echo $url; ?>/images/vina/detail/veltlinske-zelene-2018.jpg" alt="Veltlínské zelené 2018">
        <a href="<?php echo $url; ?>/vina/veltlinske-zelene-2018.php">Detail</a>
    </div>
    <div class="product-cat-title">
        <h4><a href="<?php echo $url; ?>/vina/veltlinske-zelene-2018.php">Veltlínské zelené 2018</a></h4>
        <div class="product-cats">Suché</div>
        <span class="product-price">110 Kč</span>
    </div>
</div>
<!-- product item end-->