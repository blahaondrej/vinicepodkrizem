<!-- product item-->
<div class="product-cat-mains">
    <div class="product-cat-img fl-wrap">
        <img src="<?php echo $url; ?>/images/vina/detail/ryzlink-rynsky-2016.jpg" alt="Ryzlink rýnský 2016">
        <a href="<?php echo $url; ?>/vina/ryzlink-rynsky-2016.php">Detail</a>
    </div>
    <div class="product-cat-title">
        <h4><a href="<?php echo $url; ?>/vina/ryzlink-rynsky-2016.php">Ryzlink rýnský 2016</a></h4>
        <div class="product-cats">Polosuché</div>
        <span class="product-price">110 Kč</span>
    </div>
</div>
<!-- product item end-->