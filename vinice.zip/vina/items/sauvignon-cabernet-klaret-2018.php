<!-- product item-->
<div class="product-cat-mains">
    <div class="product-cat-img fl-wrap">
        <img src="<?php echo $url; ?>/images/vina/detail/sauvignon-cabernet-klaret-2018.jpg" alt="Sauvignon Cabernet klaret 2018">
        <a href="<?php echo $url; ?>/vina/sauvignon-cabernet-klaret-2018.php">Detail</a>
    </div>
    <div class="product-cat-title">
        <h4><a href="<?php echo $url; ?>/vina/sauvignon-cabernet-klaret-2018.php">Sauvignon Cabernet klaret 2018</a></h4>
        <div class="product-cats">Polosladké</div>
        <span class="product-price">130 Kč</span>
    </div>
</div>
<!-- product item end-->